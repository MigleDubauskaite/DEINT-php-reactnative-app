import { useEffect, useState } from "react";
import {
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  View,
  Dimensions
} from "react-native";

// Importamos Card de React Native Paper
import { Card } from "react-native-paper";

import { useNavigation } from "@react-navigation/native";

// // Obtenemos el ancho de la pantalla para realizar cálculos dinámicos de diseño
// Calculamos el ancho de cada tarjeta
const { width } = Dimensions.get("window");

// Endpoint de la API REST de Studio Ghibli
const API_BASE = "https://ghibliapi.vercel.app/films/";

export default function Peliculas() {
  const [lista, setLista] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);

  // Hook para permitir el salto entre pantallas
  const navigation = useNavigation();

  useEffect(() => {
    // Definimos una función asíncrona para el consumo de la API
    const cargarDatos = async () => {
      try {
        const res = await fetch(API_BASE);

        // Verificamos si la respuesta es correcta (status 200)
        if (!res.ok) throw new Error("Error en la respuesta del servidor");

        const json = await res.json();
        setLista(json);
      } catch (e) {
        // Si hay error de red o de proceso, lo guardamos en el estado
        setError("No se pudieron cargar las películas. Revisa tu conexión.");
        console.error("Error API:", e);
      } finally {
        setCargando(false);
      }
    };

    cargarDatos();
  }, []); // El array vacío indica que solo se ejecuta al montar el componente

  // Renderizado Condicional: Estado de Carga
  if (cargando) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#e21f50" />
        <Text style={{ marginTop: 10 }}>Cargando películas...</Text>
      </View>
    );
  }

  // Renderizado Condicional: Estado de Error
  if (error) {
    return (
      <View style={styles.center}>
        <Text style={{ color: "red" }}>{error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.title}>Catálogo Ghibli</Text>
      <Text style={styles.peliculasEncontradas}>
        Películas encontradas: {lista.length}
      </Text>

      {/* Contenedor principal, para que sea responsive, agrupando todas las Card de peliculas */}
      <View style={styles.grid}>
        {/* Recoremos la lista de las peliculas creando las tarjetas*/}
        {lista.map((pelicula) => (
          <Card
            key={pelicula.id} // Identificador único para cada elemento de la lista
            style={styles.card}
            /* incluimos la navegación a componente DetallePelicula mediante objeto llamado ROUTE.
              PELI es el nombre de parametro de ROUTE que recogemos en otro componente */
            onPress={() =>
              navigation.navigate("DetallePelicula", { peli: pelicula })
            }
          >
            {/* Foto de la película usando Componente de Paper */}
            <Card.Cover source={{ uri: pelicula.image }} style={styles.cover} />

            {/* Título y Director */}
            <Card.Content style={styles.cardContent}>
              <Text style={styles.itemTitle}>{pelicula.title}</Text>
              <Text style={styles.itemDirector}>
                Director: {pelicula.director}
              </Text>
            </Card.Content>
          </Card>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#F5FBE6",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#e21f50",
    marginHorizontal: 20,
    marginTop: 20,
    marginBottom: 10,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 10, 
    justifyContent: "space-around", 
  },
  card: {
    // Cálculo: 45% del ancho para que quepan 2 con buen espacio entre ellas
    width: width * 0.44, 
    marginBottom: 25,
    backgroundColor: "#FFF",
    borderRadius: 12,
  },
  cover: {
    height: width * 0.6, // La altura también es proporcional al ancho (estilo póster)
  },
  cardContent: {
    padding: 10,
  },
  itemTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#333",
  },
  itemDirector: {
    fontSize: 12,
    color: "#777",
    marginTop: 2,
  },
});