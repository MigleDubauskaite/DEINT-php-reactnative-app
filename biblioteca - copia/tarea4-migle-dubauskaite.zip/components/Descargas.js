import { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Platform,
} from "react-native";

const API_URL = "https://espacio199.com/biblioteca/api.php";

export default function Descargas() {
  const [libros, setLibros] = useState([]);
  const [cargando, setCargando] = useState(true);

  // Carga de datos iniciales
  // Se ejecuta una sola vez al montar el componente.
  useEffect(() => {
    async function cargarDatos() {
      try {
        const respuesta = await fetch(API_URL); // consumimos los datos del api
        const datos = await respuesta.json();
        setLibros(datos); // Guardamos los datos en el estado
      } catch (error) {
        console.error("Error al obtener datos:", error);
      } finally {
        setCargando(false);
      }
    }
    cargarDatos();
  }, []);

  // Integración con Chart.js (Solo Web)
  // Ejecuta cuando los libros ya están cargados en el estado
  useEffect(() => {
    // Verificamos que estemos en plataforma Web
    if (Platform.OS === "web" && libros.length > 0) {
      import("../web/graficaDescargas").then((modulo) => {
        modulo.pintarGraficaDescargas("grafica-descargas", libros);
      });
    }
  }, [libros]);

  // Si aún no hay respuesta de la API, mostramos el spinner de carga
  if (cargando) return <ActivityIndicator size="large" />;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>📚 Descargas por libro</Text>

      {/* Utilizamos map() sobre el estado 'libros' para generar las tarjetas. */}
      <View style={styles.lista}>
        {libros.map((item, index) => (
          <View key={index} style={styles.card}>
            <Text style={styles.libro}>{item.titulo}</Text>
            <View style={styles.contDescarga}>
              <Text style={styles.descargas}>{item.total_descargas}</Text>
              <Text style={styles.txtHits}>descargas</Text>
            </View>
          </View>
        ))}
      </View>

      {/* Solo se renderiza si es entorno Web.
        nativeID="grafica-descargas" es el puente de conexión con el código JavaScript nativo. */}
      {Platform.OS === "web" && (
        <View nativeID="grafica-descargas" style={{ marginTop: 40 }} />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: "#EBF4F6", 
    padding: 16 
},
  titulo: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#3D45AA",
    textAlign: "center",
  },
  lista: { 
    marginBottom: 30 
},
  card: {
    padding: 12,
    marginBottom: 8,
    backgroundColor: "#fff",
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  libro: { 
    flex: 1, 
    fontSize: 15, 
    fontWeight: "600", 
    color: "#333" 
},
  contDescarga: { 
    alignItems: "center", 
    minWidth: 50 
},
  descargas: { 
    fontSize: 18, 
    fontWeight: "bold", 
    color: "#fd450d" 
},
  graficaSeccion: {
    marginTop: 20,
    padding: 15,
    backgroundColor: "#fff",
    borderRadius: 15,
    marginBottom: 50,
  },
  subtituloGrafica: {
    fontSize: 14,
    color: "#666",
    marginBottom: 15,
    textAlign: "center",
    fontWeight: "bold",
  },
});
